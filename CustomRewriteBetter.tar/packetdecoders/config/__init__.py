from .config import decode_packet as config_decode
from .config import config_start